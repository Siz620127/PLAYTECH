import java.io.IOException;

public class Main {
    public static void main(String[] args)  {

        // Read match_data.txt
        // Create  objekt of Match_data
        int rMt = Utils.readMatchData("match_data.txt") ;
        for(int i=0; i< Utils.arrayListMA.size() ;i++) {
            System.out.println(Utils.arrayListMA.get( i ).getuuidMa() + " " + Utils.arrayListMA.get( i ).getaRate() + " " + Utils.arrayListMA.get( i ).getbRate() + " " + Utils.arrayListMA.get( i ).getresult() );
        }
        System.out.println("");

        // Read player_data.txt
        // Create  objekt of Player_data
        int rPl = Utils.readPlayerData("player_data.txt") ;
        for(int i=0; i< Utils.arrayListPD.size() ;i++) {
            System.out.println(Utils.arrayListPD.get( i ).getuuidPl() + " " + Utils.arrayListPD.get( i ).getoperation() + " " + Utils.arrayListPD.get( i ).getuuidMa() + " " + Utils.arrayListPD.get( i ).getcoins()  + " " + Utils.arrayListPD.get( i ).getside()   + " " + Utils.arrayListPD.get( i ).getgainCoins()    );
        }
        System.out.println("");

        // Create  objekt of CasinoHost
        //CasinoHost casinoHost = CasinoHost.getInstance();
        //System.out.println(casinoHost.hashCode());

        //CasinoHost j = CasinoHost.getInstance();
        //System.out.println(j.hashCode());
        //System.out.println(casinoHost.getbalance() );

        Utils.casinoHost.print();
        System.out.println(Utils.casinoHost.getbalance() );
        System.out.println("" );



        // Create  objekt of Player
        int p = Utils.createPlayer( ) ;
        for(int i=0; i< Utils.arrayListPl.size() ;i++) {
            Utils.arrayListPl.get( i ).print();
        }
        System.out.println("");


        int cb =  Utils.calcBalance( );



        // Write to result.txt
        int wr =  Utils.writeResult(  "./out/production/Casino/result.txt"  ) ;


    }
}





