public class CasinoHost {


    private static CasinoHost instance;
    private CasinoHost(){
    }
    public static CasinoHost getInstance(){
        if(instance==null){
            instance=new CasinoHost();
        }
        return instance;
    }



        private long balance = 0 ;

        public CasinoHost( long parbalance ){
            this.balance    = parbalance;
        }

        public void print(){
            System.out.print( "balance: " + balance );
        }
        public long getbalance(){
            return this.balance  ;
        }

        public void  setbalance(long value){
            this.balance = value;
    }




        }





//}
