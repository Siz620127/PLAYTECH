public class Match_data {

    private String uuidMa = null;
    private double aRate = 0;
    private double bRate = 0;
    private String result = null;

    public Match_data( String paruuidMa, double paraRate, double parbRate, String parresult ){
        this.uuidMa    = paruuidMa;
        this.aRate     = paraRate;
        this.bRate     = parbRate;
        this.result    = parresult ;
    }

    public void print(){
        System.out.print( "uuidMa: " + uuidMa+" aRate: "+ aRate +" bRate:" + bRate + " result:" + result );
    }
    public String getuuidMa(){
        return this.uuidMa  ;
    }

    public double getaRate(){
        return this.aRate  ;
    }

    public double getbRate(){
        return this.bRate  ;
    }
    public String getresult(){
        return this.result  ;
    }




}

