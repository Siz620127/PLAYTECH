public class Player_data {

    private String uuidPl = null;
    private String operation = null;
    private String uuidMa = null;
    private int    coins = 0;
    private String side = null;
    private int    gainCoins = 0;     // = BET_COINS * SIDE_RATE
    private String status = "legit";  // legit - legitimate , illegit - illegitimate


    public Player_data( String paruuidPl, String paroperation, String paruuidMa, int parcoins, String parside, int pargainCoins , String parstatus){
        this.uuidPl    = paruuidPl;
        this.operation = paroperation;
        this.uuidMa    = paruuidMa;
        this.coins     = parcoins;
        this.side      = parside;
        this.gainCoins = pargainCoins ;
        this.status    = parstatus ;

    }

    public void print(){
        System.out.println( "uuidPl: " + uuidPl+" operation: "+ operation +" uuidMa:" + uuidMa + " coins:" + coins + " side:" + side + " gainCoins:" + gainCoins + " status:" + status   );
    }


    public String getuuidPl(){ return this.uuidPl  ;  }
    public String getoperation(){
        return this.operation  ;
    }
    public String getuuidMa(){
        return this.uuidMa  ;
    }
    public int    getcoins(){ return this.coins  ;   }
    public String getside(){
        return this.side  ;
    }
    public int    getgainCoins(){
        return this.gainCoins  ;
    }
    public String getstatus(){
        return this.status  ;
    }


    public void  setuuidPl(String value) {
        if (value.isBlank() || value.isEmpty()) {
        } else {
            this.uuidPl = value;
        }
    }
    public void  setoperation(String value){
        if (value.isBlank()  || value.isEmpty() ){
        }
        else{
            this.operation = value;
        }
    }
    public void  setuuidMa(String value){
        if (value.isBlank()  || value.isEmpty() ){
        }
        else{
            this.uuidMa = value;
        }
       }
    public void  setcoins(int value){
        if (value > 0 ){
            this.coins = value;
        }
    }
    public void  setside(String value){
        if (value.isBlank()  || value.isEmpty() ){
        }
        else{
            this.side = value;
        }
    }
    public void  setgainCoins(int value){
        //if (value > 0 ){
            this.gainCoins = value;
        //}
    }
    public void  setstatus(String value) { this.status = value;  }




}
