public class Player {

        private String uuidPl = null;
        private long balance = 0 ;
        private long wonGame = 0 ;
        private long betsNum = 0;
        private double winRate = 0;
        private String status = "legit";  // legit - legitimate , illegit - illegitimate
        private long depositCoins = 0;
        private long betCoins = 0;
        private long withdrawCoins = 0;
        private long winCoins = 0;
        private long loseCoins = 0;

        public Player( String paruuidPl, long parbalance, long parwonGame, long parbetsNum, double parwinRate, String parstatus, long pardepositCoins, long parbetCoins, long parwithdrawCoins, long parwinCoins, long parloseCoins  ){
            this.uuidPl        = paruuidPl;
            this.balance       = parbalance;
            this.wonGame       = parwonGame;
            this.betsNum       = parbetsNum;
            this.winRate       = parwinRate;
            this.status        = parstatus ;
            this.depositCoins  = pardepositCoins ;
            this.betCoins      = parbetCoins ;
            this.withdrawCoins = parwithdrawCoins ;
            this.winCoins      = parwinCoins ;
            this.loseCoins     = parloseCoins ;
        }

        public void print(){
            System.out.println( "uuidPl: " + uuidPl+" balance: "+ balance +" wonGame:" + wonGame + " betsNum:" + betsNum + " winRate:" + winRate + " status:" + status + " depositCoins:" + depositCoins + " betCoins:" + betCoins + " withdrawCoins:" + withdrawCoins + " winCoins:" + winCoins + " loseCoins:" + loseCoins );
        }

        public void printRes(){
         if (this.status.equalsIgnoreCase("legit") ) {
             System.out.println( uuidPl + " "+ balance +" " + winRate );
         }
        }
        public String getRes(){
         String res = null ;
            if (this.status.equalsIgnoreCase("legit") ) {
                res = ( uuidPl + " "+ balance +" " + winRate );
            }
            return res   ;
        }


        public String getuuidPl(){ return this.uuidPl  ;  }
        public long getbalance(){
            return this.balance  ;
        }
        public long getwonGame(){
            return this.wonGame  ;
        }
        public long getbetsNum(){  return this.betsNum  ; }
        public double getwinRate(){
            return this.winRate  ;
        }
        public String getstatus(){
            return this.status  ;
        }
        public long getdepositCoins(){
        return this.depositCoins  ;
    }
        public long getbetCoins(){
        return this.betCoins  ;
    }
        public long getwithdrawCoins(){ return this.withdrawCoins  ;  }
        public long getwinCoins(){
        return this.winCoins  ;
    }
        public long getloseCoins(){
        return this.loseCoins  ;
    }






        public void  setuuidPl(String value) {
            if (value.isBlank() || value.isEmpty()) {
            } else {
                this.uuidPl = value;
            }
        }
        public void  setbalance(long value){
                this.balance = value;
        }
        public void  setwonGame(long value){
                this.wonGame = value;
        }
        public void  setbetsNum(long value){
                this.betsNum = value;
        }
        public void  setwinRate(double value){
                this.winRate = value;
        }
        public void  setstatus(String value){
            if (value.isBlank()  || value.isEmpty() ){
            }
            else{
                this.status = value;
            }
        }
        public void  setdepositCoins(long  value){
                this.depositCoins = value;
        }
        public void  setbetCoins(long  value){
                this.betCoins = value;
        }
       public void  setwithdrawCoins(long  value){
               this.withdrawCoins = value;
       }
       public void  setwinCoins(long  value){
               this.winCoins = value;
       }
       public void  setloseCoins(long  value){
               this.loseCoins = value;
       }




    }




