
import java.io.*;

import java.util.*;


public class Utils {

        public static  ArrayList<Match_data> arrayListMA  = new ArrayList<>();
        public static  ArrayList<Player_data> arrayListPD = new ArrayList<>();
        public static  ArrayList<Player> arrayListPl      = new ArrayList<>();
        public static  CasinoHost casinoHost = new CasinoHost( 0 ) ;



        public static int  readMatchData(String parSrc)  {  // throws IOException
           String row = null ;
           int    res = 0 ;
           int    i   = 0 ;

            try (
            BufferedReader txtReader = new BufferedReader(new FileReader(parSrc)) ;
            ) {
                while ((row = txtReader.readLine()) != null) {
                    String[] data = row.split(",");
                    // create Match_data object
                    Match_data md = new Match_data(data[0], Double.parseDouble(data[1]), Double.parseDouble(data[2]), data[3]);
                    //md.print();

                    arrayListMA.add( md ) ;
                    //System.out.println(arrayListMA.size());
                    //System.out.println(arrayListMA.get( i ).getuuidMa() + " " + arrayListMA.get( i ).getaRate() + " " + arrayListMA.get( i ).getbRate() + " " + arrayListMA.get( i ).getresult() );
                    //System.out.println("");

                    i = i + 1 ;

                }

                txtReader.close();
            }
            catch (FileNotFoundException e){
                e.printStackTrace();
            }
            catch (IOException r){
                r.printStackTrace();
            }

            return res ;

        }


        public static int  readPlayerData(String parSrc)  {  // throws IOException
            String row = null ;

            Scanner scanner  = null ;
            String uuidPl    = null;
            String operation = null;
            String uuidMa    = null;
            int    coins     = 0;
            String side      = null;
            int    gainCoins = 0;      // = BET_COINS * SIDE_RATE
            String status    = "";     // legit - legitimate , illegit - illegitimate



            int    res = 0 ;
            int    i   = 0 ;
            int    index   = 0 ;

            try (
                    BufferedReader txtReader = new BufferedReader(new FileReader(parSrc)) ;
            ) {

                while ((row = txtReader.readLine()) != null) {

                    scanner = new Scanner(row) ;
                    scanner.useDelimiter("," ) ;
                    while (scanner.hasNext()){
                        String dat = scanner.next();
                        //System.out.println("dat  "+ dat );
                        if      (index  == 0 ) uuidPl    = dat ;
                        else if ( index == 1 ) operation = dat ;
                        else if ( index == 2 ) uuidMa    = dat ;
                        else if ( index == 3 ) coins     = Integer.parseInt( dat ) ;
                        else if ( index == 4 ) side      = dat ;
                        else System.out.println("Uncorrect data "+ dat );
                        index++ ;
                    }
                    index = 0 ;


                    // create Player_data object
                    Player_data pd = new Player_data( uuidPl, operation, uuidMa  , coins,  side    , gainCoins , status );
                    arrayListPD.add( pd ) ;
                    //pd.print();
                    //System.out.println(arrayListPL.size());
                    //System.out.println(arrayListPL.get( i ).getuuidPl() + " " + arrayListPL.get( i ).getoperation() + " " + arrayListPL.get( i ).getuuidMa() + " " + arrayListPL.get( i ).getcoins()  + " " + arrayListPL.get( i ).getside()   + " " + arrayListPL.get( i ).getgainCoins()    );
                    //System.out.println("");

                    i = i + 1 ;
                }

                txtReader.close();
            }
            catch (FileNotFoundException e){
                e.printStackTrace();
            }
            catch (IOException r){
                r.printStackTrace();
            }

            return res ;

        }



    public static int  createPlayer( )  {  // throws IOException
        String  curuuidPl = "";

        String  uuidPl    = null;
        String  operation = null;
        String  uuidMa    = null;
        int     coins     = 0;
        String  side      = null;
        int     gainCoins = 0;      // = BET_COINS * SIDE_RATE
        String  status    = "";     // legit - legitimate , illegit - illegitimate

        long    balance       = 0 ;
        long    wonGame       = 0 ;
        long    betsNum       = 0;
        double  winRate       = 0;
        long    depositCoins  = 0;
        long    betCoins      = 0;
        long    withdrawCoins = 0;
        long    winCoins      = 0;
        long    loseCoins     = 0;

        int    res = 0 ;

        for(int i = 0; i < Utils.arrayListPD.size() ; i++) {

              uuidPl      = Utils.arrayListPD.get( i ).getuuidPl() ;
              operation   = Utils.arrayListPD.get( i ).getoperation() ;
              uuidMa      = Utils.arrayListPD.get( i ).getuuidMa() ;
              coins       = Utils.arrayListPD.get( i ).getcoins() ;
              side        = Utils.arrayListPD.get( i ).getside() ;
              gainCoins   = Utils.arrayListPD.get( i ).getgainCoins() ;      // = BET_COINS * SIDE_RATE
              status      = Utils.arrayListPD.get( i ).getstatus() ;         // legit - legitimate , illegit - illegitimate


              if     ( operation.equalsIgnoreCase("DEPOSIT") ){
                      balance        = balance + coins;
                      wonGame        = wonGame ;
                      betsNum        = betsNum ;
                      winRate        = winRate ;
                      status         = status ;
                      depositCoins   = depositCoins + coins ;
                      betCoins       = betCoins ;
                      withdrawCoins  = withdrawCoins ;
                      winCoins       = winCoins ;
                      loseCoins      = loseCoins ;
              }


               else if ( operation.equalsIgnoreCase("BET")  ) {
                  balance        = balance  - coins;
                  wonGame        = wonGame ;
                  betsNum        = betsNum ;
                  winRate        = winRate ;
                  status         = status ;
                  depositCoins   = depositCoins ;
                  betCoins       = betCoins + coins;
                  withdrawCoins  = withdrawCoins ;
                  winCoins       = winCoins ;
                  loseCoins      = loseCoins ;

              }

              else if ( operation.equalsIgnoreCase("WITHDRAW")  ) {
                  balance        = balance  + coins;
                  wonGame        = wonGame ;
                  betsNum        = betsNum ;
                  winRate        = winRate ;
                  status         = status ;
                  depositCoins   = depositCoins ;
                  betCoins       = betCoins  ;
                  withdrawCoins  = withdrawCoins + coins ;
                  winCoins       = winCoins ;
                  loseCoins      = loseCoins ;

              }

              else {
                  System.out.println( "Wrong operation " +  operation   );
              }



            if ( curuuidPl.isEmpty() || curuuidPl.isBlank()
                 ||
                 ! curuuidPl.equalsIgnoreCase( Utils.arrayListPD.get( i ).getuuidPl() ) ) {
              //Player pl  = new Player( uuidPl , balance, wonGame, betsNum, winRate, status , depositCoins  , betCoins, withdrawCoins, winCoins, loseCoins  ) ;
                Player pl  = new Player( uuidPl , 0, 0, 0, 0, "" , 0  , 0, 0, 0, 0  ) ;

              arrayListPl.add( pl ) ;
              curuuidPl  = uuidPl ;

                balance        = 0 ;
                wonGame        = 0 ;
                betsNum        = 0 ;
                winRate        = 0 ;
                status         = null ;
                depositCoins   = 0 ;
                betCoins       = 0 ;
                withdrawCoins  = 0 ;
                winCoins       = 0 ;
                loseCoins      = 0 ;
            }


            System.out.println(Utils.arrayListPD.get( i ).getuuidPl() + " " + Utils.arrayListPD.get( i ).getoperation() + " " + Utils.arrayListPD.get( i ).getuuidMa() + " " + Utils.arrayListPD.get( i ).getcoins()  + " " + Utils.arrayListPD.get( i ).getside()   + " " + Utils.arrayListPD.get( i ).getgainCoins()    );
        }

        return res ;

    }






    public static int  writeResult(String parSrc)  {  // throws IOException
        String row = null ;

        String  uuidPl        = null;
        long    balance       = 0 ;
        long    wonGame       = 0 ;
        long    betsNum       = 0;
        double  winRate       = 0;
        String  status        = "";     // legit - legitimate , illegit - illegitimate
        long    depositCoins  = 0;
        long    betCoins      = 0;
        long    withdrawCoins = 0;
        long    winCoins      = 0;      // = BET_COINS * SIDE_RATE
        long    loseCoins     = 0;


        int    res          = 0 ;
        int    legitCount   = 0 ;
        int    illegitCount = 0 ;


        try ( FileWriter txtWriter = new FileWriter( parSrc) ;  // " ./out/production/Casino/result.txt"
        ) {

            // List of legitimate player
            for (int i = 0; i < Utils.arrayListPl.size(); i++) {
                if ( Utils.arrayListPl.get(i).getstatus().equalsIgnoreCase("legit") ) {
                    legitCount++;
                }
            }

            System.out.println("Legitimate players  " + legitCount );
            System.out.println("" );

            if ( Utils.arrayListPl.size() > 0 && legitCount > 0   ) {  // && legitCount > 0

            for (int i = 0; i < Utils.arrayListPl.size(); i++) {  // &&

                if( Utils.arrayListPl.get(i).getstatus().equalsIgnoreCase("legit") ) {
                    Utils.arrayListPl.get(i).print();

                    txtWriter.append(Utils.arrayListPl.get(i).getuuidPl());
                    txtWriter.append(" ");
                    txtWriter.append(Long.toString(Utils.arrayListPl.get(i).getbalance()));
                    txtWriter.append(" ");
                    txtWriter.append(Double.toString(Math.round(Utils.arrayListPl.get(i).getwinRate() * 100.00) / 100.00));
                    txtWriter.append("\n");
                }


            }
                txtWriter.append("\n");
            }
            else { txtWriter.append("\n"); }
            // ---------------------

            // List of illegitimate players
            for (int i = 0; i < Utils.arrayListPD.size(); i++) {
              if ( Utils.arrayListPD.get(i).getstatus().equalsIgnoreCase("illegit") ) {
                  illegitCount++;
              }
            }

            System.out.println("Ilegitimate player_data  " + illegitCount );
            System.out.println("" );

            if ( Utils.arrayListPD.size() > 0  && illegitCount > 0  ) {  // && illegitCount > 0

                for (int i = 0; i < Utils.arrayListPD.size(); i++) {

                    if( Utils.arrayListPD.get(i).getstatus().equalsIgnoreCase("illegit") ) {

                        Utils.arrayListPD.get(i).print();

                        txtWriter.append(Utils.arrayListPD.get(i).getuuidPl());
                        txtWriter.append(" ");
                        txtWriter.append(Utils.arrayListPD.get(i).getoperation());
                        txtWriter.append(" ");
                        String uuidMa = Utils.arrayListPD.get(i).getuuidMa() + "";
                        txtWriter.append((uuidMa.isEmpty() ? "null" : Utils.arrayListPD.get(i).getuuidMa()));
                        txtWriter.append(" ");
                        txtWriter.append(String.valueOf(Utils.arrayListPD.get(i).getcoins()));
                        txtWriter.append(" ");
                        String side = Utils.arrayListPD.get(i).getside() + "";
                        txtWriter.append((side.isEmpty() ? "null" : Utils.arrayListPD.get(i).getside()));
                        txtWriter.append("\n");

                    }
                }
                txtWriter.append("\n");
            }
            else { txtWriter.append("\n"); }


            // ---------------------


            // Casino host balance
            txtWriter.append( Long.toString(Utils.casinoHost.getbalance()  )  );

            // ---------------------

                txtWriter.flush();
                txtWriter.close();

        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException r){
            r.printStackTrace();
        }

        return res ;

    }



    public static int  calcBalance( )  {  // throws IOException
        String  curuuidPl = "";

        String  uuidPl        = null;
        String  operation     = null;
        String  uuidMa        = null;
        int     coins         = 0;
        String  side          = null;
        int     gainCoins     = 0;      // = BET_COINS * SIDE_RATE
        String  status        = "";     // legit - legitimate , illegit - illegitimate

        long    balance       = 0 ;
        long    wonGame       = 0 ;
        long    betsNum       = 0;
        double  winRate       = 0;
        String  statusPl      = null  ;
        long    depositCoins  = 0;
        long    betCoins      = 0;
        long    withdrawCoins = 0;
        long    winCoins      = 0;
        long    loseCoins     = 0;

        double aRate          = 0;
        double bRate          = 0;
        String result         = null;

        long    balanceCA     = 0 ;

        int     iPl           = 0 ;
        int     iMA           = 0 ;

        int    res = 0 ;

        for(int i = 0; i < Utils.arrayListPD.size() ; i++) {

            uuidPl      = Utils.arrayListPD.get( i ).getuuidPl() ;
            operation   = Utils.arrayListPD.get( i ).getoperation() ;
            uuidMa      = Utils.arrayListPD.get( i ).getuuidMa() ;
            coins       = Utils.arrayListPD.get( i ).getcoins() ;
            side        = Utils.arrayListPD.get( i ).getside() ;
            gainCoins   = Utils.arrayListPD.get( i ).getgainCoins() ;      // = BET_COINS * SIDE_RATE
            status      = Utils.arrayListPD.get( i ).getstatus() ;         // legit - legitimate , illegit - illegitimate

            iPl = Utils.getiPl(  uuidPl  ) ;
            iMA = Utils.getiMA(  uuidMa  ) ;

            balance       = Utils.arrayListPl.get( iPl ).getbalance()      ;
            wonGame       = Utils.arrayListPl.get( iPl ).getwonGame()      ;
            betsNum       = Utils.arrayListPl.get( iPl ).getbetsNum()      ;
            winRate       = Utils.arrayListPl.get( iPl ).getwinRate()      ;
            statusPl      = Utils.arrayListPl.get( iPl ).getstatus() + ""   ;
            depositCoins  = Utils.arrayListPl.get( iPl ).getdepositCoins()  ;
            betCoins      = Utils.arrayListPl.get( iPl ).getbetCoins()      ;
            withdrawCoins = Utils.arrayListPl.get( iPl ).getwithdrawCoins() ;
            winCoins      = Utils.arrayListPl.get( iPl ).getwinCoins()      ;
            loseCoins     = Utils.arrayListPl.get( iPl ).getloseCoins()     ;

            aRate          = Utils.arrayListMA.get( iMA ).getaRate()  ;
            bRate          = Utils.arrayListMA.get( iMA ).getbRate()  ;
            result         = Utils.arrayListMA.get( iMA ).getresult()  ;

            balanceCA =  Utils.casinoHost.getbalance()  ;

            if     (    operation.equalsIgnoreCase("DEPOSIT")
                    && ! statusPl.equalsIgnoreCase("illegit" ) ){

                balance        = balance + coins;
                wonGame        = wonGame ;
                betsNum        = betsNum ;
                winRate        = winRate ;
                status         = "legit" ;
                depositCoins   = depositCoins + coins ;
                betCoins       = betCoins ;
                withdrawCoins  = withdrawCoins ;
                winCoins       = winCoins ;
                loseCoins      = loseCoins ;

                Utils.arrayListPl.get( iPl ).setbalance( balance );
                Utils.arrayListPl.get( iPl ).setdepositCoins( depositCoins ) ;
                Utils.arrayListPl.get( iPl ).setstatus("legit"); ;

                Utils.arrayListPD.get( i ).setstatus("legit");
            }


            else if (   operation.equalsIgnoreCase("BET")
                    && ! statusPl.equalsIgnoreCase("illegit" ) ) {


                if(    coins > balance
                    || coins <= 0
                ){
                    Utils.arrayListPl.get( iPl ).setstatus("illegit"); ;
                    Utils.arrayListPD.get( i ).setstatus("illegit");
                }

                else {
                    betsNum++ ;
                    gainCoins = Utils.getGainCoins(coins, side, aRate, bRate, result);

                    if (gainCoins > 0) {
                        balance   = balance   + gainCoins;
                        balanceCA = balanceCA - gainCoins;

                        wonGame++ ;

                        winCoins = winCoins  +  gainCoins - coins;
                        loseCoins = loseCoins;


                    } else if (gainCoins < 0) {
                        balance   = balance   + gainCoins;
                        balanceCA = balanceCA - gainCoins;

                        winCoins = winCoins  ;
                        loseCoins = loseCoins +  gainCoins ;


                    } else if (gainCoins == 0) {
                        balance   = balance   + coins;
                        balanceCA = balanceCA - coins;

                    } else {
                        System.out.println("Wrong gainCoins " + gainCoins);
                    }

                    //balance = balance - coins;
                    wonGame = wonGame;
                    betsNum = betsNum;
                    winRate = (double)wonGame / betsNum ;
                    status = status;
                    depositCoins = depositCoins;
                    betCoins = betCoins + coins;
                    withdrawCoins = withdrawCoins;
                    //winCoins = winCoins;
                    //loseCoins = loseCoins;

                    Utils.arrayListPl.get( iPl ).setbalance( balance );
                    Utils.arrayListPl.get( iPl ).setwonGame(wonGame);
                    Utils.arrayListPl.get( iPl ).setbetsNum(betsNum);
                    Utils.arrayListPl.get( iPl ).setwinRate(winRate);
                    Utils.arrayListPl.get( iPl ).setstatus("legit");
                    Utils.arrayListPl.get( iPl ).setbetCoins(betCoins);
                    Utils.arrayListPl.get( iPl ).setwinCoins(winCoins);
                    Utils.arrayListPl.get( iPl ).setloseCoins(loseCoins);

                    Utils.arrayListPD.get( i ).setstatus("legit");
                    Utils.casinoHost.setbalance( balanceCA );

                }


            }

            else if (   operation.equalsIgnoreCase("WITHDRAW")
                    && ! statusPl.equalsIgnoreCase("illegit" )
            ) {

                if(    coins > balance
                        || coins <= 0
                ){
                    Utils.arrayListPl.get( iPl ).setstatus("illegit"); ;
                    Utils.arrayListPD.get( i ).setstatus("illegit");
                }

                else {


                    balance = balance - coins;
                    wonGame = wonGame;
                    betsNum = betsNum;
                    winRate = winRate;
                    status = status;
                    depositCoins = depositCoins;
                    betCoins = betCoins;
                    withdrawCoins = withdrawCoins + coins;
                    winCoins = winCoins;
                    loseCoins = loseCoins;

                    balanceCA = balanceCA + coins;

                    Utils.arrayListPl.get( iPl ).setbalance( balance );
                    //Utils.arrayListPl.get( iPl ).setwonGame(wonGame);
                    //Utils.arrayListPl.get( iPl ).setbetsNum(betsNum);
                    //Utils.arrayListPl.get( iPl ).setwinRate(winRate);
                    Utils.arrayListPl.get( iPl ).setstatus("legit");
                    //Utils.arrayListPl.get( iPl ).setbetCoins(betCoins);
                    //Utils.arrayListPl.get( iPl ).setwinCoins(winCoins);
                    //Utils.arrayListPl.get( iPl ).setloseCoins(loseCoins);

                    Utils.arrayListPD.get( i ).setstatus("legit");
                    Utils.casinoHost.setbalance( balanceCA );



                }
            }



            else {
                System.out.println( "Wrong operation " +  operation   );
            }


            //System.out.println(Utils.arrayListPD.get( i ).getuuidPl() + " " + Utils.arrayListPD.get( i ).getoperation() + " " + Utils.arrayListPD.get( i ).getuuidMa() + " " + Utils.arrayListPD.get( i ).getcoins()  + " " + Utils.arrayListPD.get( i ).getside()   + " " + Utils.arrayListPD.get( i ).getgainCoins()    );
        }

        return res ;

    }



    public static int  getiPl(  String paruuidPl  )  {  // throws IOException
        int    iPl = 0 ;
        for(int i = 0; i < Utils.arrayListPl.size() ; i++) {
            if     ( Utils.arrayListPl.get( i ).getuuidPl().equalsIgnoreCase(paruuidPl) ) {
                iPl = i;
            }
        }
        return iPl  ;
    }

    public static int  getiMA(  String paruuidMA  )  {  // throws IOException
        int    iMA = 0 ;
        for(int i = 0; i < Utils.arrayListMA.size() ; i++) {
            if     ( Utils.arrayListMA.get( i ).getuuidMa().equalsIgnoreCase(paruuidMA) ) {
                iMA = i;
            }
        }
        return iMA  ;
    }

    public static int  getGainCoins(  int parcoins , String parside   ,double paraRate, double parbRate, String parResult  )  {
       int    gainCoins = 0 ;

            if     (   parResult.equalsIgnoreCase( parside  )
                    && parResult.equalsIgnoreCase( "A"  )
            ) {     gainCoins = (int)(parcoins * paraRate) ;  }

            else if (   parResult.equalsIgnoreCase( parside  )
                     && parResult.equalsIgnoreCase( "B"  )
            ) {     gainCoins = (int)(parcoins * parbRate) ;  }

            else if (   parResult.equalsIgnoreCase( "DRAW"  )
            ) {     gainCoins = 0 ;  }

            else if ( !  parResult.equalsIgnoreCase( parside  )
            ) {     gainCoins =  - parcoins  ;  }

       return gainCoins  ;
    }











}









